function validateLogin(event) {
    event.preventDefault(); // Previne trimiterea formularului

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username === "admin" && password === "admin") {
        // Dacă user și parola sunt corecte, deschide o pagină goală
        window.open('about:blank', '_self');
        window.close();
    } else {
        alert("Username sau parola incorectă. Încearcă din nou.");
    }
}
