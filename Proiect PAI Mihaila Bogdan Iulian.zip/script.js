let lastTimestamp = Date.now(); // Timpul ultimei măsurători
let lastCounter = 0; // Valoarea anterioară a contorului
const pulsesPerRevolution = 20; // Impulsuri per rotație

// Referințe la grafice
let rpmChart, voltageChart;

// Funcție pentru crearea unui grafic (pentru RPM și Tensiune)
function createChart(canvasId, label, yLabel) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    const labels = [];
    const dataPoints = [];

    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: dataPoints,
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false,
            }]
        },
        options: {
            scales: {
                x: { title: { display: true, text: 'Timp (s)' } },
                y: { title: { display: true, text: yLabel } }
            }
        }
    });

    let time = 0;

    function updateChart(value, currentTimestamp) {
        const timeElapsed = (currentTimestamp - lastTimestamp) / 1000; // Calculăm timpul în secunde

        labels.push(timeElapsed); // Timpul pe axa X
        dataPoints.push(value); // Valoarea pentru RPM sau Tensiune pe axa Y

        chart.update();

        if (labels.length > 100) { // Menține 50 de puncte pe grafic
            labels.shift();
            dataPoints.shift();
        }
    }

    return updateChart; // Întoarce funcția pentru actualizarea graficului
}

// Creăm două grafice pentru RPM și Tensiune
const updateRPMChart = createChart('temperatureChart1', 'RPM', 'RPM');
const updateVoltageChart = createChart('temperatureChart2', 'Tensiune (V)', 'Tensiune (V)');

let port; // Variabilă pentru port
let reader; // Reader pentru fluxul de date seriale

// Adăugăm un event listener pentru butonul de conectare
document.getElementById('checkConnection').addEventListener('click', async () => {
    try {
        // Solicită conectarea la dispozitivul serial
        port = await navigator.serial.requestPort();
        await port.open({ baudRate: 115200 }); // Arduino Uno folosește de obicei 9600

        document.getElementById('statusText').textContent = "Conexiune realizată cu succes";
        displayError('Conexiune realizată cu succes', 'success');
        console.log("Conexiune la Arduino Uno realizată cu succes.");

        // Schimbă vizibilitatea butoanelor
        document.getElementById('checkConnection').style.display = 'none';
        document.getElementById('disconnectConnection').style.display = 'block';

        startReadingData(); // Pornește citirea datelor
    } catch (error) {
        document.getElementById('statusText').textContent = "Eroare la conectare!";
        console.error("Eroare conectare:", error);
    }
});

// Funcție pentru a începe citirea datelor
async function startReadingData() {
    const decoder = new TextDecoderStream();
    const inputDone = port.readable.pipeTo(decoder.writable);
    const inputStream = decoder.readable;
    reader = inputStream.getReader();

    const consoleOutput = document.getElementById('consoleOutput'); // Referință la consola din HTML
    const counterDisplay = document.getElementById('counterValue');
    const xDisplay = document.getElementById('xValue');
    const yDisplay = document.getElementById('yValue');
    const zDisplay = document.getElementById('zValue');
    const voltageDisplay = document.getElementById('voltageValue');

    let buffer = ""; // Buffer pentru a aduna datele

    try {
        while (true) {
            const { value, done } = await reader.read();
            if (done) {
                console.log("Citirea s-a încheiat.");
                break;
            }

            if (value) {
                buffer += value; // Adăugăm datele citite în buffer

                // Împărțim bufferul pe linii complete (terminatoare de linie '\n')
                const lines = buffer.split('\n');
                buffer = lines.pop(); // Ultima linie (posibil incompletă) rămâne în buffer

                for (const line of lines) {
                    const trimmedLine = line.trim(); // Eliminăm spațiile albe
                    const data = trimmedLine.split(' '); // Împărțim datele pe spații
                    
                    consoleOutput.textContent += `Date: ${data.join(', ')} \n`;
                    // Extragem datele relevante
                    const dataString = data.join(' ');

                    const regex = /Counter:([-]?\d+) X:(\d+) Y:(\d+) Z:(\d+) Voltage:(\d+\.\d+)/;

                    const match = regex.exec(dataString);

                    if (match) {
                        const counter = match[1];
                        const x = match[2];
                        const y = match[3];
                        const z = match[4];
                        const voltage = match[5];

                        // Actualizăm valorile în patratele HTML
                        counterDisplay.textContent = Math.round(Math.abs(counter) / 710);
                        xDisplay.textContent = x;
                        yDisplay.textContent = y;
                        zDisplay.textContent = z;
                        voltageDisplay.textContent = voltage;

                        // Calculăm RPM (Rotatii pe minut)
                        const currentTimestamp = Date.now();
                        const timeDiff = (currentTimestamp - lastTimestamp) / 1000; // Secunde între măsurători
                        const counterDiff = Math.abs(counter - lastCounter); // Diferența de contor

                        const rpm = (counterDiff / timeDiff) * pulsesPerRevolution; // RPM calculat

                        // Actualizăm graficele
                        updateRPMChart(rpm, currentTimestamp);
                        updateVoltageChart(parseFloat(voltage), currentTimestamp);

                        // Salvăm valorile pentru următoarea măsurătoare
                        lastTimestamp = currentTimestamp;
                        lastCounter = counter;

                        console.log("Date REGEX: ", match[1], " ", match[2], " ", match[3], " ", match[4], " ", match[5]);
                    }
                }

                consoleOutput.scrollTop = consoleOutput.scrollHeight;
            }
        }
    } catch (error) {
        console.error("Eroare citire serială:", error);
        document.getElementById('statusText').textContent = "Eroare citire date.";
    } finally {
        reader.releaseLock();
    }
}

// Evenimentul pentru închiderea conexiunii înainte de închidere
window.addEventListener('beforeunload', async () => {
    if (reader) {
        await reader.cancel();
        reader.releaseLock();
    }
    if (port) {
        await port.close();
    }
});

// Eveniment pentru deconectarea dispozitivului
document.getElementById('disconnectConnection').addEventListener('click', async () => {
    try {
        document.getElementById('statusText').textContent = "Fără conexiune!";
        document.getElementById('checkConnection').style.display = 'block';
        document.getElementById('disconnectConnection').style.display = 'none';

        if (reader) {
            await reader.cancel();
            reader.releaseLock();
        }
        if (port) {
            await port.close();
        }

        console.log("Conexiune închisă.");

        // Schimbă vizibilitatea butoanelor
        document.getElementById('checkConnection').style.display = 'block';
        document.getElementById('disconnectConnection').style.display = 'none';
    } catch (error) {
        console.error("Eroare la deconectare:", error);
    }
});

// Funcție pentru a adăuga un mesaj în zona de erori
function displayError(message, type = 'error') {
    const errorList = document.getElementById('error-list');
    const newError = document.createElement('li');
    
    newError.textContent = message;

    // Adaugă clase în funcție de tipul mesajului (eroare, avertisment, succes)
    newError.classList.add(type);

    // Adaugă mesajul la listă
    errorList.appendChild(newError);
}




